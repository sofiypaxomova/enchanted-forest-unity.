# Зачарованный лес — подготовка iOS Cloud Build

Этот архив — **подготовительный Unity-проект**, а не готовое приложение `.ipa`.
Он содержит исходный Stage 10 и Editor-скрипт для настройки iOS и экспорта Xcode-проекта.

## Важно о текущем статусе

- Проект не был открыт и собран в Unity Editor в этой среде.
- Наличие компилируемых C#-скриптов и работоспособность сцен ещё нужно проверить в Unity.
- В исходном пакете нет гарантированно готовой игровой сцены: перед сборкой добавьте свои сцены в `File > Build Settings > Scenes In Build`.
- `com.example.enchantedforest` — временный Bundle Identifier. Замените его на уникальный до подписания.
- В архиве нет сертификатов, provisioning profile, паролей или Apple ID.

## Что нужно для сборки без собственного Mac

1. Создать учётную запись Unity и открыть Unity Build Automation:
   https://unity.com/products/build-automation
2. Создать Git-репозиторий и загрузить в него содержимое папки `EnchantedForest_Unity`.
3. В Unity Dashboard подключить репозиторий и выбрать ветку проекта.
4. Выбрать совместимую версию Unity 2022.3 LTS и платформу iOS.
5. Для подписанного iOS-приложения настроить Apple signing credentials и provisioning profile в соответствии с инструкциями Unity:
   https://docs.unity.com/en-us/build-automation/sign-build-artifacts/sign-an-ios-application
6. Запустить сборку и проверить Build Logs. Сначала можно получить Xcode project/build artifact; для установки на iPhone нужен корректно подписанный пакет.

## Настройки iOS в проекте

В Unity Editor откройте меню:

`Enchanted Forest > iOS > Prepare iOS Cloud Build`

Скрипт выставляет:
- iPhone/iPad;
- iOS deployment target 13.0;
- ARM64;
- IL2CPP;
- альбомную ориентацию;
- Bundle ID-заглушку `com.example.enchantedforest`.

Экспорт Xcode-проекта локально (если редактор запущен на подходящей машине):

`Enchanted Forest > iOS > Export Xcode Project`

## Ограничение Apple ID без платного членства

Бесплатная Apple Account позволяет тестировать приложение на собственном устройстве через Xcode Personal Team, но такой путь требует Xcode на Mac и периодического переподписания. TestFlight, App Store Connect и обычная раздача через TestFlight требуют Apple Developer Program. Актуальные условия Apple:
https://developer.apple.com/programs/
https://developer.apple.com/help/account/basics/about-your-developer-account/

Следовательно, при текущих условиях (только iPhone, без Mac и без платного членства) облачная сборка сама по себе ещё не даст устанавливаемый TestFlight build. Сначала можно подготовить проект и проверить компиляцию; для установки потребуется позднее подключить платную учётную запись Apple Developer либо получить помощь человека/команды с доступом к Mac и подходящей подписью.

## Следующий технический шаг

Провести проект через Unity Editor/Unity Build Automation, устранить ошибки импорта и компиляции, добавить проверенные игровые сцены, затем настроить подпись. Не загружайте в репозиторий приватные ключи и пароли.
