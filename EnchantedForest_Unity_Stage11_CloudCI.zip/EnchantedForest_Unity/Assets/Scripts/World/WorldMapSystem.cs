using System;
using UnityEngine;

public enum WorldRegionId { FairyKingdom, TrollValley, LeshyForest, MirrorLake, FloatingIsles, ForgottenCity, ShadowCastle }

[Serializable]
public class WorldRegionData
{
    public WorldRegionId id;
    public string title;
    [TextArea] public string description;
    [Range(0, 7)] public int requiredSparks;
    public Vector3 spawnPosition;
}

/// <summary>Progression and travel between the seven story regions.</summary>
public class WorldMapSystem : MonoBehaviour
{
    public static WorldMapSystem Instance { get; private set; }
    public WorldRegionData[] regions;
    public event Action<WorldRegionData> RegionTravelled;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        if (regions == null || regions.Length == 0) regions = DefaultRegions();
    }

    public bool IsUnlocked(WorldRegionData region) => SaveProgress.GetSparks() >= region.requiredSparks;
    public bool TravelTo(WorldRegionId id)
    {
        var region = Array.Find(regions, r => r.id == id);
        if (region == null || !IsUnlocked(region)) return false;
        var player = GameObject.FindGameObjectWithTag("Player");
        if (player != null)
        {
            var controller = player.GetComponent<CharacterController>();
            if (controller) controller.enabled = false;
            player.transform.position = region.spawnPosition;
            if (controller) controller.enabled = true;
        }
        PlayerPrefs.SetInt("EF_Visited_" + id, 1);
        PlayerPrefs.Save();
        RegionTravelled?.Invoke(region);
        return true;
    }
    public bool HasVisited(WorldRegionId id) => PlayerPrefs.GetInt("EF_Visited_" + id, 0) == 1;

    public static WorldRegionData[] DefaultRegions() => new WorldRegionData[] {
        new WorldRegionData{id=WorldRegionId.FairyKingdom,title="Королевство фей",description="Дом Элианы и начало великого приключения.",requiredSparks=0,spawnPosition=new Vector3(0,0,0)},
        new WorldRegionData{id=WorldRegionId.TrollValley,title="Долина троллей",description="Каменные мосты, пещеры и мастерские Брума.",requiredSparks=1,spawnPosition=new Vector3(120,0,0)},
        new WorldRegionData{id=WorldRegionId.LeshyForest,title="Лес лешего",description="Древние деревья и тропы, которые меняют направление.",requiredSparks=2,spawnPosition=new Vector3(240,0,0)},
        new WorldRegionData{id=WorldRegionId.MirrorLake,title="Зеркальное озеро",description="Вода хранит воспоминания о прошлом.",requiredSparks=3,spawnPosition=new Vector3(360,0,0)},
        new WorldRegionData{id=WorldRegionId.FloatingIsles,title="Парящие острова",description="Небесные тропы и потоки ветра.",requiredSparks=4,spawnPosition=new Vector3(480,0,0)},
        new WorldRegionData{id=WorldRegionId.ForgottenCity,title="Забытый город",description="Затерянные библиотеки древней цивилизации.",requiredSparks=5,spawnPosition=new Vector3(600,0,0)},
        new WorldRegionData{id=WorldRegionId.ShadowCastle,title="Замок Тени",description="Последнее испытание и тайна семи искр.",requiredSparks=7,spawnPosition=new Vector3(720,0,0)}
    };
}
