using UnityEngine;

[RequireComponent(typeof(Collider))]
public class RegionPortal : MonoBehaviour
{
    public WorldRegionId destination;
    public bool requireInteraction = true;
    bool playerInside;
    void Reset(){GetComponent<Collider>().isTrigger=true;}
    void Update(){if(requireInteraction && playerInside && (Input.GetKeyDown(KeyCode.E)||Input.GetKeyDown(KeyCode.JoystickButton0))) Travel();}
    void OnTriggerEnter(Collider other){if(other.CompareTag("Player")){playerInside=true;if(!requireInteraction)Travel();}}
    void OnTriggerExit(Collider other){if(other.CompareTag("Player"))playerInside=false;}
    public void Travel(){if(WorldMapSystem.Instance && !WorldMapSystem.Instance.TravelTo(destination))Debug.Log("Портал пока закрыт. Собери больше магических искр.");}
}
