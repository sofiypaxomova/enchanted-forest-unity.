using UnityEngine;

public class CombatHealth : MonoBehaviour
{
    [SerializeField] int maxHealth = 100;
    [SerializeField] bool isPlayer;
    int currentHealth;
    public int CurrentHealth => currentHealth;
    public int MaxHealth => maxHealth;
    public bool IsDead { get; private set; }

    void Awake() { currentHealth = maxHealth; }
    public void TakeDamage(int amount)
    {
        if (IsDead || amount <= 0) return;
        currentHealth = Mathf.Max(0, currentHealth - amount);
        if (currentHealth == 0)
        {
            IsDead = true;
            if (!isPlayer) Destroy(gameObject, 1.2f);
            else if (MagicCaster.Instance != null) MagicCaster.Instance.SetControlsEnabled(false);
        }
    }
    public void Heal(int amount)
    {
        if (IsDead || amount <= 0) return;
        currentHealth = Mathf.Min(maxHealth, currentHealth + amount);
    }
    void OnGUI()
    {
        if (!isPlayer) return;
        GUI.color = new Color(0.05f,0.08f,0.1f,0.85f);
        GUI.Box(new Rect(12, Screen.height - 58, 210, 42), GUIContent.none);
        GUI.color = Color.white;
        GUI.Label(new Rect(22, Screen.height - 50, 190, 26), "ЗДОРОВЬЕ  " + currentHealth + "/" + maxHealth);
        GUI.color = Color.Lerp(Color.red, Color.green, (float)currentHealth / maxHealth);
        GUI.Box(new Rect(22, Screen.height - 27, 180f * currentHealth / maxHealth, 8), GUIContent.none);
        GUI.color = Color.white;
        if (IsDead) GUI.Label(new Rect(Screen.width/2-100, Screen.height/2, 220, 40), "Герой пал. Перезапусти сцену.");
    }
}
