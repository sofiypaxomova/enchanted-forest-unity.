using UnityEngine;

[RequireComponent(typeof(CombatHealth))]
public class ForestEnemy : MonoBehaviour
{
    [SerializeField] float noticeDistance = 12f;
    [SerializeField] float moveSpeed = 2.1f;
    [SerializeField] float attackDistance = 1.8f;
    [SerializeField] int damage = 12;
    [SerializeField] float attackCooldown = 1.7f;
    Transform target;
    float nextAttack;
    CombatHealth health;

    void Start()
    {
        health = GetComponent<CombatHealth>();
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null) target = player.transform;
    }
    void Update()
    {
        if (target == null || health.IsDead) return;
        Vector3 delta = target.position - transform.position;
        delta.y = 0;
        if (delta.magnitude > noticeDistance) return;
        if (delta.magnitude > attackDistance)
        {
            transform.position += delta.normalized * moveSpeed * Time.deltaTime;
            if (delta.sqrMagnitude > 0.01f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(delta), 8f * Time.deltaTime);
        }
        else if (Time.time >= nextAttack)
        {
            nextAttack = Time.time + attackCooldown;
            CombatHealth playerHealth = target.GetComponentInParent<CombatHealth>();
            if (playerHealth != null) playerHealth.TakeDamage(damage);
        }
    }
}
