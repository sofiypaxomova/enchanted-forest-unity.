using UnityEngine;

public class MagicCaster : MonoBehaviour
{
    public static MagicCaster Instance { get; private set; }
    [SerializeField] Transform firePoint;
    [SerializeField] float castCooldown = 0.55f;
    [SerializeField] int mana = 100;
    [SerializeField] int manaCost = 15;
    [SerializeField] float manaRegen = 8f;
    float nextCast;
    bool controlsEnabled = true;
    public int Mana => mana;

    void Awake() { Instance = this; }
    void Update()
    {
        if (mana < 100) mana = Mathf.Min(100, mana + Mathf.CeilToInt(manaRegen * Time.deltaTime));
        if (controlsEnabled && (Input.GetKeyDown(KeyCode.F) || Input.GetButtonDown("Fire1"))) Cast();
    }
    public void Cast()
    {
        if (!controlsEnabled || Time.time < nextCast || mana < manaCost) return;
        nextCast = Time.time + castCooldown;
        mana -= manaCost;
        Transform origin = firePoint != null ? firePoint : transform;
        Vector3 start = origin.position + origin.forward * 0.8f + Vector3.up * 0.8f;
        GameObject orb = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        orb.name = "Magic Spark Projectile";
        orb.transform.position = start;
        orb.transform.localScale = Vector3.one * 0.42f;
        Collider col = orb.GetComponent<Collider>();
        col.isTrigger = true;
        Rigidbody body = orb.AddComponent<Rigidbody>();
        body.useGravity = false; body.isKinematic = true;
        orb.AddComponent<MagicProjectile>().Launch(origin.forward);
        orb.GetComponent<Renderer>().material.color = new Color(0.25f, 0.85f, 1f);
    }
    public void SetControlsEnabled(bool enabled) { controlsEnabled = enabled; }
    void OnGUI()
    {
        if (!controlsEnabled) return;
        GUI.color = new Color(0.05f,0.08f,0.1f,0.82f);
        GUI.Box(new Rect(Screen.width-150, Screen.height-86, 138, 74), GUIContent.none);
        GUI.color = Color.white;
        GUI.Label(new Rect(Screen.width-140, Screen.height-78, 120, 22), "МАНА  " + mana + "/100");
        if (GUI.Button(new Rect(Screen.width-140, Screen.height-48, 118, 30), "ИСКРА  [F]")) Cast();
    }
}
