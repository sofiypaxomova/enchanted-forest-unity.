using UnityEngine;

public class MagicProjectile : MonoBehaviour
{
    [SerializeField] float speed = 16f;
    [SerializeField] int damage = 35;
    [SerializeField] float lifetime = 4f;
    Vector3 direction;
    public void Launch(Vector3 dir) { direction = dir.normalized; Destroy(gameObject, lifetime); }
    void Update() { transform.position += direction * speed * Time.deltaTime; }
    void OnTriggerEnter(Collider other)
    {
        CombatHealth health = other.GetComponentInParent<CombatHealth>();
        if (health != null && !health.IsDead && !health.CompareTag("Player"))
        {
            health.TakeDamage(damage);
            Destroy(gameObject);
        }
        else if (!other.isTrigger && !other.CompareTag("Player")) Destroy(gameObject);
    }
}
