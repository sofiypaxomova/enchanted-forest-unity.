using UnityEngine;
public static class SaveProgress
{
    const string SparksKey="EF_Sparks", SeedsKey="EF_Seeds";
    public static int GetSparks()=>PlayerPrefs.GetInt(SparksKey,0);
    public static int GetSeeds()=>PlayerPrefs.GetInt(SeedsKey,0);
    public static void SetSparks(int value){PlayerPrefs.SetInt(SparksKey,Mathf.Clamp(value,0,7));PlayerPrefs.Save();}
    public static void SetSeeds(int value){PlayerPrefs.SetInt(SeedsKey,Mathf.Clamp(value,0,3));PlayerPrefs.Save();}
    public static void Reset(){PlayerPrefs.DeleteKey(SparksKey);PlayerPrefs.DeleteKey(SeedsKey);PlayerPrefs.Save();}
}
