using UnityEngine;
using UnityEngine.UI;

/// <summary>Build a simple responsive map panel at runtime; connect its button to Toggle().</summary>
public class WorldMapPanel : MonoBehaviour
{
    public Canvas canvas;
    GameObject panel;
    Text details;
    Font font;
    WorldRegionId? selectedRegion;
    void Start(){ if(!canvas) canvas=FindObjectOfType<Canvas>(); font=Resources.GetBuiltinResource<Font>("Arial.ttf"); Build(); }
    public void Toggle(){ if(panel) panel.SetActive(!panel.activeSelf); Refresh(); }
    void Build()
    {
        if(!canvas) return;
        panel=new GameObject("World Map Panel",typeof(RectTransform),typeof(Image)); panel.transform.SetParent(canvas.transform,false);
        var rt=panel.GetComponent<RectTransform>(); rt.anchorMin=new Vector2(.08f,.08f);rt.anchorMax=new Vector2(.92f,.92f);rt.offsetMin=rt.offsetMax=Vector2.zero;
        panel.GetComponent<Image>().color=new Color(.035f,.09f,.075f,.97f);
        var heading=MakeText(panel.transform,"КАРТА СЕМИ ЗЕМЕЛЬ",26,TextAnchor.MiddleCenter); Place(heading.rectTransform,new Vector2(.04f,.86f),new Vector2(.96f,.98f));
        details=MakeText(panel.transform,"Выбери открытую землю.",16,TextAnchor.UpperLeft); Place(details.rectTransform,new Vector2(.05f,.05f),new Vector2(.95f,.25f));
        var mapRoot=new GameObject("Region Buttons",typeof(RectTransform));mapRoot.transform.SetParent(panel.transform,false);Place(mapRoot.GetComponent<RectTransform>(),new Vector2(.04f,.28f),new Vector2(.96f,.84f));
        var regions=WorldMapSystem.Instance ? WorldMapSystem.Instance.regions : WorldMapSystem.DefaultRegions();
        for(int i=0;i<regions.Length;i++)
        {
            int index=i; var b=new GameObject("Region "+i,typeof(RectTransform),typeof(Image),typeof(Button));b.transform.SetParent(mapRoot.transform,false);
            var br=b.GetComponent<RectTransform>();br.anchorMin=new Vector2(.03f+(i%2)*.49f,.78f-(i/2)*.25f);br.anchorMax=new Vector2(.47f+(i%2)*.49f,.96f-(i/2)*.25f);br.offsetMin=br.offsetMax=Vector2.zero;
            var label=MakeText(b.transform,"",14,TextAnchor.MiddleCenter);Place(label.rectTransform,Vector2.zero,Vector2.one);
            b.GetComponent<Button>().onClick.AddListener(()=>SelectRegion(regions[index]));
        }
        Refresh(); panel.SetActive(false);
    }
    Text MakeText(Transform parent,string value,int size,TextAnchor align)
    {
        var go=new GameObject("Text",typeof(RectTransform),typeof(Text));go.transform.SetParent(parent,false);var t=go.GetComponent<Text>();t.font=font;t.text=value;t.fontSize=size;t.alignment=align;t.color=Color.white;t.horizontalOverflow=HorizontalWrapMode.Wrap;t.verticalOverflow=VerticalWrapMode.Truncate;return t;
    }
    void Place(RectTransform r,Vector2 min,Vector2 max){r.anchorMin=min;r.anchorMax=max;r.offsetMin=r.offsetMax=Vector2.zero;}
    void SelectRegion(WorldRegionData region)
    {
        bool unlocked=WorldMapSystem.Instance && WorldMapSystem.Instance.IsUnlocked(region);
        details.text=region.title+"\n"+region.description+"\n"+(unlocked?"Земля открыта — нажми ещё раз для путешествия.":"Нужно искр: "+region.requiredSparks+". У тебя: "+SaveProgress.GetSparks());
        if(!unlocked) { selectedRegion=null; return; }
        if(selectedRegion == region.id) { WorldMapSystem.Instance.TravelTo(region.id); }
        else selectedRegion = region.id;
    }
    void Refresh(){ if(details) details.text="Искры: "+SaveProgress.GetSparks()+" / 7\nОткрытые земли отмечены доступными для путешествия."; }
}
