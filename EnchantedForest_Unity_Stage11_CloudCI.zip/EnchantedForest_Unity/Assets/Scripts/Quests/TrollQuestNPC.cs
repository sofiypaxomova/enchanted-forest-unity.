using UnityEngine;

/// <summary>Talk/interact trigger for Broom. Call Interact from a mobile UI button too.</summary>
[RequireComponent(typeof(Collider))]
public class TrollQuestNPC : MonoBehaviour
{
    public string npcName = "Брум";
    public float interactionDistance = 3f;
    bool playerNearby;

    void Reset() { GetComponent<Collider>().isTrigger = true; }
    void OnTriggerEnter(Collider other) { if (other.CompareTag("Player")) playerNearby = true; }
    void OnTriggerExit(Collider other) { if (other.CompareTag("Player")) playerNearby = false; }

    void Update()
    {
        if (playerNearby && (Input.GetKeyDown(KeyCode.E) || Input.GetKeyDown(KeyCode.JoystickButton0))) Interact();
    }

    public void Interact()
    {
        var quests = ForestQuestSystem.Instance;
        if (!quests) { Debug.LogWarning("Add ForestQuestSystem to the scene."); return; }
        if (quests.Completed) quests.ClaimReward();
        else quests.BeginTrollQuest();
    }
}
