using UnityEngine;

/// <summary>Small persistent quest flow for the first story chapter.</summary>
public class ForestQuestSystem : MonoBehaviour
{
    public static ForestQuestSystem Instance { get; private set; }
    const string QuestStateKey = "EF_Quest_TrollSeeds";
    const string TalkedKey = "EF_Quest_TrollTalked";
    const string RewardKey = "EF_Quest_TrollReward";
    [SerializeField] int requiredSeeds = 3;
    string message = "Найди Брума в Долине троллей.";
    float messageUntil;

    public int SeedsCollected => Mathf.Min(PlayerPrefs.GetInt(QuestStateKey, 0), requiredSeeds);
    public bool Started => PlayerPrefs.GetInt(TalkedKey, 0) == 1;
    public bool Completed => SeedsCollected >= requiredSeeds;
    public bool RewardClaimed => PlayerPrefs.GetInt(RewardKey, 0) == 1;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    public void BeginTrollQuest()
    {
        if (!Started) { PlayerPrefs.SetInt(TalkedKey, 1); PlayerPrefs.Save(); }
        Notify(Completed ? "Брум: Ты нашёл все семена!" : "Брум: Собери три светящихся семени в долине.");
    }

    public void RegisterSeed()
    {
        if (!Started || Completed) return;
        int count = Mathf.Min(requiredSeeds, SeedsCollected + 1);
        PlayerPrefs.SetInt(QuestStateKey, count); PlayerPrefs.Save();
        Notify(count >= requiredSeeds ? "Задание выполнено! Вернись к Бруму." : "Семя найдено: " + count + "/" + requiredSeeds);
    }

    public void ClaimReward()
    {
        if (!Started) { Notify("Сначала поговори с Брумом."); return; }
        if (!Completed) { Notify("Брум: Нам нужны все три семени."); return; }
        if (RewardClaimed) { Notify("Брум: Спасибо, хранитель леса!"); return; }
        PlayerPrefs.SetInt(RewardKey, 1); PlayerPrefs.Save();
        SaveProgress.SetSparks(SaveProgress.GetSparks() + 1);
        Notify("Получена искра света!");
    }

    public void Notify(string text) { message = text; messageUntil = Time.time + 5f; }

    void OnGUI()
    {
        if (!Started) return;
        GUI.color = new Color(0.06f, 0.10f, 0.12f, 0.88f);
        GUI.Box(new Rect(12, 12, 280, 74), GUIContent.none);
        GUI.color = Color.white;
        GUI.Label(new Rect(24, 20, 255, 24), "ЗАДАНИЕ: Семена света");
        GUI.Label(new Rect(24, 45, 255, 28), Completed ? (RewardClaimed ? "Награда получена" : "Вернись к Бруму за наградой") : "Семена: " + SeedsCollected + "/" + requiredSeeds);
        if (Time.time < messageUntil)
        {
            GUI.color = new Color(0.06f, 0.10f, 0.12f, 0.92f);
            GUI.Box(new Rect(12, 94, 340, 48), GUIContent.none);
            GUI.color = Color.white;
            GUI.Label(new Rect(24, 105, 320, 28), message);
        }
    }
}
