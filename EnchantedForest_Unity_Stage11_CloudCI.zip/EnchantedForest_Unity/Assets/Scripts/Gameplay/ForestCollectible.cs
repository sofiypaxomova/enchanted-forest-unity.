using UnityEngine;

/// <summary>Simple trigger collectible. Attach to a trigger collider with a visible child mesh.</summary>
[RequireComponent(typeof(Collider))]
public class ForestCollectible : MonoBehaviour
{
    public enum RewardType { Seed, Spark }
    public RewardType reward = RewardType.Seed;
    [Min(1)] public int amount = 1;
    public bool destroyOnCollect = true;
    public AudioClip collectSound;

    void Reset()
    {
        var c = GetComponent<Collider>();
        c.isTrigger = true;
    }

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        if (reward == RewardType.Seed)
        {
            int before = SaveProgress.GetSeeds();
            SaveProgress.SetSeeds(before + amount);
            if (ForestQuestSystem.Instance)
                for (int i = 0; i < amount; i++) ForestQuestSystem.Instance.RegisterSeed();
        }
        else SaveProgress.SetSparks(SaveProgress.GetSparks() + amount);
        if (collectSound) AudioSource.PlayClipAtPoint(collectSound, transform.position);
        if (destroyOnCollect) Destroy(gameObject);
        else gameObject.SetActive(false);
    }
}
