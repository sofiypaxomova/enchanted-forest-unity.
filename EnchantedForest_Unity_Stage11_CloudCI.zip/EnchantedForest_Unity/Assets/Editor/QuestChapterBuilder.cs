using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class QuestChapterBuilder
{
    [MenuItem("Enchanted Forest/Install Troll Quest Chapter")]
    public static void Build()
    {
        var system = Object.FindObjectOfType<ForestQuestSystem>();
        if (!system) new GameObject("Forest Quest System").AddComponent<ForestQuestSystem>();

        var existing = GameObject.Find("Broom Quest NPC");
        if (existing) Object.DestroyImmediate(existing);
        var npc = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        npc.name = "Broom Quest NPC";
        npc.transform.position = new Vector3(120, 1, -5);
        npc.transform.localScale = new Vector3(1.2f, 1.8f, 1.2f);
        var renderer = npc.GetComponent<Renderer>();
        var shader = Shader.Find("Standard");
        if (shader) { var mat = new Material(shader); mat.color = new Color(.35f,.48f,.28f); renderer.sharedMaterial = mat; }
        var body = npc.GetComponent<CapsuleCollider>(); body.isTrigger = true; body.radius = 2.8f;
        npc.AddComponent<TrollQuestNPC>();
        var label = new GameObject("Broom Name"); label.transform.SetParent(npc.transform);
        label.transform.localPosition = new Vector3(0, 1.8f, 0);
        var text = label.AddComponent<TextMesh>(); text.text = "БРУМ • E"; text.fontSize = 48; text.characterSize = .12f; text.anchor = TextAnchor.MiddleCenter; text.color = Color.white;

        EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
        Selection.activeGameObject = npc;
        Debug.Log("Troll quest chapter installed. Place Broom at the Troll Valley spawn near X=120.");
    }
}
