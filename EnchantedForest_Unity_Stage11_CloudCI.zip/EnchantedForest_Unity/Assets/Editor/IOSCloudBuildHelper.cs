#if UNITY_EDITOR
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.iOS.Xcode;
using UnityEngine;

public static class IOSCloudBuildHelper
{
    private const string BundleId = "com.example.enchantedforest";

    [MenuItem("Enchanted Forest/iOS/Prepare iOS Cloud Build")]
    public static void Prepare()
    {
        PlayerSettings.productName = "Enchanted Forest";
        PlayerSettings.companyName = "Replace With Your Studio Name";
        PlayerSettings.bundleVersion = "0.1.0";
        PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.iOS, BundleId);
        PlayerSettings.iOS.buildNumber = "1";
        PlayerSettings.iOS.targetDevice = iOSTargetDevice.iPhoneAndiPad;
        PlayerSettings.iOS.targetOSVersionString = "13.0";
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        PlayerSettings.allowedAutorotateToPortrait = false;
        PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
        PlayerSettings.allowedAutorotateToLandscapeLeft = true;
        PlayerSettings.allowedAutorotateToLandscapeRight = true;
        PlayerSettings.SetScriptingBackend(BuildTargetGroup.iOS, ScriptingImplementation.IL2CPP);
        PlayerSettings.iOS.architecture = iOSArchitecture.ARM64;
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.iOS, BuildTarget.iOS);
        Debug.Log("iOS settings prepared. Replace bundle ID and company name before signing.");
    }

    [MenuItem("Enchanted Forest/iOS/Export Xcode Project")]
    public static void ExportXcodeProject()
    {
        Prepare();

        string[] scenes = EditorBuildSettings.scenes;
        if (scenes == null || scenes.Length == 0)
        {
            EditorUtility.DisplayDialog(
                "No scenes in Build Settings",
                "Add your playable scenes in File > Build Settings > Scenes In Build, then run this command again.",
                "OK");
            return;
        }

        string output = EditorUtility.SaveFolderPanel(
            "Choose iOS Xcode project output folder",
            "Builds",
            "EnchantedForest_iOS");

        if (string.IsNullOrEmpty(output))
            return;

        var options = new BuildPlayerOptions
        {
            scenes = System.Array.FindAll(scenes, s => s.enabled).Select(s => s.path).ToArray(),
            locationPathName = output,
            target = BuildTarget.iOS,
            options = BuildOptions.None
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result == BuildResult.Succeeded)
            EditorUtility.DisplayDialog("iOS project exported", "Xcode project created at:\n" + output, "OK");
        else
            EditorUtility.DisplayDialog("iOS export failed", report.summary.result + "\n" + report.summary.totalErrors + " errors. See Console/Build Report.", "OK");
    }
}
#endif
