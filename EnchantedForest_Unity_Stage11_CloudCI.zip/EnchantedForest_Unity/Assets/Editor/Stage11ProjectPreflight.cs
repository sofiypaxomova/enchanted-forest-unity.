\
    #if UNITY_EDITOR
    using System.IO;
    using UnityEditor;
    using UnityEditor.Build;
    using UnityEditor.Build.Reporting;
    using UnityEngine;

    public static class Stage11ProjectPreflight
    {
        [MenuItem("Enchanted Forest/iOS/Run Project Preflight")]
        public static void Run()
        {
            Debug.Log("=== Enchanted Forest iOS Preflight ===");

            string projectVersion = Path.Combine(Directory.GetCurrentDirectory(),
                "ProjectSettings/ProjectVersion.txt");
            Debug.Log(File.Exists(projectVersion)
                ? "ProjectVersion.txt: found"
                : "WARNING: ProjectVersion.txt not found");

            var scenes = EditorBuildSettings.scenes;
            int enabledScenes = 0;
            foreach (var scene in scenes)
            {
                if (scene.enabled)
                {
                    enabledScenes++;
                    Debug.Log("Build scene: " + scene.path);
                    if (!File.Exists(scene.path))
                        Debug.LogError("Missing scene file: " + scene.path);
                }
            }

            if (enabledScenes == 0)
                Debug.LogError("No enabled scenes in Build Settings. Add the game's entry scene.");

            string bundleId = PlayerSettings.GetApplicationIdentifier(BuildTargetGroup.iOS);
            Debug.Log("iOS Bundle Identifier: " + bundleId);
            if (string.IsNullOrEmpty(bundleId) || bundleId.Contains("example"))
                Debug.LogWarning("Set a unique iOS Bundle Identifier before signing.");

            Debug.Log("Preflight finished. Review Console for warnings/errors; this is not a build.");
            EditorUtility.DisplayDialog(
                "iOS Preflight finished",
                "Preflight checks completed. Review the Unity Console for missing scenes and configuration warnings.",
                "OK");
        }
    }
    #endif
