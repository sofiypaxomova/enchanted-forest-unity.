using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Builds lightweight placeholder environments for all seven map destinations.</summary>
public static class SevenRegionsBuilder
{
    static readonly string[] Names = { "Королевство фей", "Долина троллей", "Лес лешего", "Зеркальное озеро", "Парящие острова", "Забытый город", "Замок Тени" };
    static readonly Color[] Colors = {
        new Color(.28f,.62f,.34f), new Color(.43f,.39f,.31f), new Color(.16f,.38f,.23f),
        new Color(.16f,.48f,.62f), new Color(.48f,.62f,.72f), new Color(.55f,.48f,.34f), new Color(.20f,.18f,.29f)
    };
    static readonly Vector3[] Centers = { Vector3.zero, new Vector3(120,0,0), new Vector3(240,0,0), new Vector3(360,0,0), new Vector3(480,0,0), new Vector3(600,0,0), new Vector3(720,0,0) };

    [MenuItem("Enchanted Forest/Build Seven Region Environments")]
    public static void Build()
    {
        var old = GameObject.Find("Generated Seven Regions");
        if (old) Object.DestroyImmediate(old);
        var root = new GameObject("Generated Seven Regions");
        for (int i = 0; i < Centers.Length; i++) BuildRegion(root.transform, i);
        var map = Object.FindObjectOfType<WorldMapSystem>();
        if (map)
        {
            if (map.regions == null || map.regions.Length == 0) map.regions = WorldMapSystem.DefaultRegions();
            for (int i = 0; i < map.regions.Length; i++) map.regions[i].spawnPosition = Centers[i] + Vector3.up;
            EditorUtility.SetDirty(map);
        }
        EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
        Selection.activeGameObject = root;
        Debug.Log("Seven region prototypes generated. Save the scene to keep the changes.");
    }

    static void BuildRegion(Transform parent, int index)
    {
        var center = Centers[index];
        var region = new GameObject("Region_" + index + "_" + Names[index]);
        region.transform.SetParent(parent);
        region.transform.position = center;
        var ground = Mat(Colors[index]);
        var accent = Mat(Color.Lerp(Colors[index], Color.white, .35f));
        var dark = Mat(Color.Lerp(Colors[index], Color.black, .35f));
        Cube(region.transform, "Island Ground", center + new Vector3(0,-1,0), new Vector3(48,2,48), ground);
        var label = new GameObject("Region Name"); label.transform.SetParent(region.transform);
        label.transform.position = center + new Vector3(0,5,-19);
        var tm = label.AddComponent<TextMesh>(); tm.text = Names[index]; tm.fontSize = 48; tm.characterSize = .18f; tm.anchor = TextAnchor.MiddleCenter; tm.color = Color.white;

        // Boundary stones make each destination legible without expensive terrain assets.
        for (int n=0;n<12;n++)
        {
            float a = n * Mathf.PI * 2f / 12f;
            Vector3 p = center + new Vector3(Mathf.Cos(a)*22f, .1f, Mathf.Sin(a)*22f);
            Cube(region.transform, "Boundary Rock", p, new Vector3(2.2f, Random.Range(1.4f,3.4f),2.2f), dark);
        }
        if (index == 3) // Mirror Lake
        {
            var water = GameObject.CreatePrimitive(PrimitiveType.Cylinder); water.name="Mirror Lake"; water.transform.SetParent(region.transform);
            water.transform.position=center+new Vector3(0,.08f,0); water.transform.localScale=new Vector3(15,.08f,15);
            water.GetComponent<Renderer>().sharedMaterial=Mat(new Color(.12f,.58f,.78f,.8f));
        }
        else
        {
            for (int n=0;n<9;n++)
            {
                Vector3 p=center+new Vector3(Random.Range(-17,18),0,Random.Range(-15,16));
                if (p.x-center.x > -4 && p.x-center.x < 4 && p.z-center.z > -4 && p.z-center.z < 4) continue;
                BuildTree(region.transform,p,accent,dark,index);
            }
        }
        // Landmark at the north edge; varies by region.
        if (index == 1) BuildCave(region.transform, center, dark, accent);
        else if (index == 4) BuildFloatingPillars(region.transform, center, accent, dark);
        else BuildLandmark(region.transform, center, accent, dark, index);

        // Three seeds in the Troll Valley provide the first story milestone.
        if (index == 1)
            for (int n=0;n<3;n++) CreateSeed(region.transform, center+new Vector3(-8+n*8,1.2f,5+(n%2)*5));
    }

    static void BuildTree(Transform parent, Vector3 p, Material leaves, Material trunk, int type)
    {
        Cube(parent,"Tree Trunk",p+Vector3.up*2,new Vector3(1.1f,4,1.1f),trunk);
        var crown=GameObject.CreatePrimitive(PrimitiveType.Sphere); crown.name="Tree Crown"; crown.transform.SetParent(parent);
        crown.transform.position=p+Vector3.up*5; crown.transform.localScale=Vector3.one*(type==2?5.5f:3.8f); crown.GetComponent<Renderer>().sharedMaterial=leaves;
    }
    static void BuildCave(Transform parent, Vector3 c, Material rock, Material light)
    {
        Cube(parent,"Cave Left",c+new Vector3(-3,2,15),new Vector3(3,4,2),rock);
        Cube(parent,"Cave Right",c+new Vector3(3,2,15),new Vector3(3,4,2),rock);
        Cube(parent,"Cave Lintel",c+new Vector3(0,4,15),new Vector3(9,2,2),rock);
        Cube(parent,"Workshop Marker",c+new Vector3(0,1,18),new Vector3(2,2,1),light);
    }
    static void BuildFloatingPillars(Transform parent, Vector3 c, Material a, Material b)
    {
        for(int i=0;i<5;i++) Cube(parent,"Sky Pillar",c+new Vector3(-12+i*6,2+(i%2)*2,12),new Vector3(3,4+(i%2)*4,3),i%2==0?a:b);
    }
    static void BuildLandmark(Transform parent, Vector3 c, Material a, Material b, int i)
    {
        Cube(parent,"Ancient Landmark",c+new Vector3(0,2,15),new Vector3(5,4,2),b);
        Cube(parent,"Landmark Top",c+new Vector3(0,4.5f,15),new Vector3(7,1,3),a);
        for(int k=-1;k<=1;k++) Cube(parent,"Pillar",c+new Vector3(k*3,2,17),new Vector3(1,4,1),a);
    }
    static void CreateSeed(Transform parent, Vector3 p)
    {
        var seed=GameObject.CreatePrimitive(PrimitiveType.Sphere); seed.name="Story Seed"; seed.transform.SetParent(parent);
        seed.transform.position=p; seed.transform.localScale=Vector3.one*.85f;
        seed.GetComponent<Renderer>().sharedMaterial=Mat(new Color(.35f,1f,.55f));
        var col=seed.GetComponent<SphereCollider>(); col.isTrigger=true;
        seed.AddComponent<ForestCollectible>().reward=ForestCollectible.RewardType.Seed;
    }
    static void Cube(Transform parent,string name,Vector3 pos,Vector3 scale,Material mat)
    {
        var go=GameObject.CreatePrimitive(PrimitiveType.Cube); go.name=name; go.transform.SetParent(parent);
        go.transform.position=pos; go.transform.localScale=scale; go.GetComponent<Renderer>().sharedMaterial=mat;
    }
    static Material Mat(Color c)
    {
        const string folder = "Assets/Generated/Materials";
        if (!AssetDatabase.IsValidFolder("Assets/Generated")) AssetDatabase.CreateFolder("Assets", "Generated");
        if (!AssetDatabase.IsValidFolder(folder)) AssetDatabase.CreateFolder("Assets/Generated", "Materials");
        string key = ColorUtility.ToHtmlStringRGB(c);
        string path = folder + "/EF_" + key + ".mat";
        var existing = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (existing) return existing;
        var shader = Shader.Find("Standard");
        if (!shader) shader = Shader.Find("Universal Render Pipeline/Lit");
        var material = new Material(shader); material.color = c;
        AssetDatabase.CreateAsset(material, path);
        return material;
    }
}
