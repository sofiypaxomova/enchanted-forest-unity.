using UnityEditor;
using UnityEngine;

public static class CombatChapterBuilder
{
    [MenuItem("Enchanted Forest/Install Magic Combat Chapter")]
    public static void Install()
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player == null) { Debug.LogError("Создай объект героя и назначь ему тег Player."); return; }
        if (player.GetComponent<CombatHealth>() == null)
        {
            CombatHealth hp = player.AddComponent<CombatHealth>();
            SerializedObject so = new SerializedObject(hp);
            so.FindProperty("isPlayer").boolValue = true;
            so.ApplyModifiedProperties();
        }
        if (player.GetComponent<MagicCaster>() == null) player.AddComponent<MagicCaster>();
        Vector3 center = player.transform.position + player.transform.forward * 10f;
        CreateEnemy("Лесной шипоклык", center + new Vector3(3,0,2), new Color(0.35f,0.55f,0.22f), 90);
        CreateEnemy("Теневой шипоклык", center + new Vector3(-4,0,7), new Color(0.28f,0.18f,0.38f), 120);
        Debug.Log("Глава магии установлена: герою добавлены здоровье и заклинание, созданы два врага.");
    }
    static void CreateEnemy(string enemyName, Vector3 position, Color color, int hp)
    {
        GameObject enemy = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        enemy.name = enemyName; enemy.transform.position = position;
        enemy.transform.localScale = new Vector3(1.15f,1.25f,1.15f);
        enemy.GetComponent<Renderer>().sharedMaterial = MakeMaterial(color);
        CombatHealth health = enemy.AddComponent<CombatHealth>();
        SerializedObject so = new SerializedObject(health);
        so.FindProperty("maxHealth").intValue = hp; so.ApplyModifiedProperties();
        enemy.AddComponent<ForestEnemy>();
    }
    static Material MakeMaterial(Color color)
    {
        Shader shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Universal Render Pipeline/Lit");
        Material material = new Material(shader); material.color = color; return material;
    }
}
