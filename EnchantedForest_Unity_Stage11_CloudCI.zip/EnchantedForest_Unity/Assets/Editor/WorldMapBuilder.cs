using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public static class WorldMapBuilder
{
    [MenuItem("Enchanted Forest/Install Seven Lands Map")]
    public static void Install()
    {
        var existing=GameObject.Find("World Map Systems");if(existing)Object.DestroyImmediate(existing);
        var root=new GameObject("World Map Systems");root.AddComponent<WorldMapSystem>();
        var canvas=Object.FindObjectOfType<Canvas>();
        if(canvas)
        {
            var map=root.AddComponent<WorldMapPanel>();map.canvas=canvas;
            var button=new GameObject("КАРТА",typeof(RectTransform),typeof(Image),typeof(Button));button.transform.SetParent(canvas.transform,false);
            var rt=button.GetComponent<RectTransform>();rt.anchorMin=rt.anchorMax=new Vector2(.87f,.9f);rt.sizeDelta=new Vector2(150,58);
            button.GetComponent<Image>().color=new Color(.12f,.28f,.19f,.94f);
            var labelGo=new GameObject("Label",typeof(RectTransform),typeof(Text));labelGo.transform.SetParent(button.transform,false);
            var lr=labelGo.GetComponent<RectTransform>();lr.anchorMin=Vector2.zero;lr.anchorMax=Vector2.one;lr.offsetMin=lr.offsetMax=Vector2.zero;
            var label=labelGo.GetComponent<Text>();label.font=Resources.GetBuiltinResource<Font>("Arial.ttf");label.text="КАРТА";label.fontSize=22;label.alignment=TextAnchor.MiddleCenter;label.color=Color.white;
            button.GetComponent<Button>().onClick.AddListener(map.Toggle);
        }
        else Debug.LogWarning("Карта установлена без кнопки UI: в сцене нет Canvas. Добавь Canvas и WorldMapPanel.");
        EditorUtility.SetDirty(root);
        Debug.Log("Установлена карта семи земель. Проверь точки появления регионов и расставь порталы в сцене.");
    }
}
