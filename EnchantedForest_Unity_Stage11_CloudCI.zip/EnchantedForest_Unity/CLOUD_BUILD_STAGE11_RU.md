# Этап 11 — подготовка репозитория и облачной iOS-сборки

## Что добавлено
- `.gitignore` для Unity, Xcode и локальных артефактов сборки.
- этот чек-лист настройки Unity Build Automation;
- контрольный список для первичной проверки проекта перед сборкой.

## Важное ограничение
Этот этап подготавливает исходный репозиторий к подключению к облачному сервису.
Он не создаёт `.ipa`, не подписывает приложение и не подключается к вашим аккаунтам.
Проверка проекта в Unity Editor/Unity Build Automation ещё не выполнена.

## 1. Подготовить GitHub-репозиторий с iPhone
1. Откройте https://github.com/ и войдите или создайте аккаунт.
2. Создайте новый приватный репозиторий, например `enchanted-forest-unity`.
3. Распакуйте архив на устройстве/в облачном файловом хранилище, доступном для загрузки в GitHub.
4. Загрузите содержимое папки `EnchantedForest_Unity` в корень репозитория.
5. Убедитесь, что в корне репозитория видны `Assets`, `ProjectSettings`, `Packages` (если присутствует), `.gitignore`.
6. Не загружайте пароли, Apple-сертификаты, `.p12`, provisioning profiles или приватные ключи.

## 2. Подключить Unity Build Automation
1. Откройте https://dashboard.unity3d.com/ и выберите организацию/проект.
2. Откройте Build Automation: https://unity.com/products/build-automation
3. Создайте build target для iOS.
4. Подключите GitHub и разрешите доступ только к нужному репозиторию.
5. Укажите ветку `main` (или фактическое имя основной ветки).
6. Выберите версию Unity, совпадающую с `ProjectSettings/ProjectVersion.txt`.
7. Настройте iOS build target. На первом проходе цель — проверить импорт и получить Xcode project/build logs, а не публикацию в TestFlight.

## 3. Проверить проект до первой сборки
- В Unity Dashboard build logs проверьте ошибки импорта и компиляции.
- Убедитесь, что игровые сцены внесены в Build Settings / Scenes In Build.
- Проверьте, что Bundle Identifier заменён с `com.example.enchantedforest` на уникальный.
- Убедитесь, что все используемые плагины поддерживают iOS.
- Исправьте ошибки до настройки подписи.

## 4. Подпись и установка на iPhone — позже
Для TestFlight потребуется Apple Developer Program и настройки подписи в App Store Connect.
Не передавайте пароль Apple Account, одноразовые коды и приватные ключи в чат.
Справка Apple: https://developer.apple.com/programs/
Справка Unity по iOS signing: https://docs.unity.com/en-us/build-automation/sign-build-artifacts/sign-an-ios-application

## Что нужно от пользователя для следующего шага
После создания репозитория пришлите только его URL и уточните, удалось ли загрузить папку проекта.
Не присылайте токены доступа, пароли или секреты.
