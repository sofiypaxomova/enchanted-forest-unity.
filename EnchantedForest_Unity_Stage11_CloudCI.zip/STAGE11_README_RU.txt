Этап 11: подготовка репозитория и preflight для облачной iOS-сборки.
См. EnchantedForest_Unity/CLOUD_BUILD_STAGE11_RU.md.
Это не подписанный iOS build и не IPA.
